function sum(){
  let count=1;
  let sum=0;
 while(count<=100){
  sum+=count;
  count++;
  }
  return sum;
};

console.log(sum())