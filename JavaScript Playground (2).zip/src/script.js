const message = ['apple',"mango","banana"] // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)